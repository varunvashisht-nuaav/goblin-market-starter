using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace GoblinMarket.Api.Streaming;

/// <summary>Writes Server-Sent Events: "event: NAME\ndata: JSON\n\n".</summary>
public sealed class SseWriter(HttpResponse response)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    public async Task SendAsync(string eventName, object payload)
    {
        var frame = $"event: {eventName}\ndata: {JsonSerializer.Serialize(payload, Json)}\n\n";
        await NetworkConditions.WriteAsync(response, Encoding.UTF8.GetBytes(frame));
    }
}

/// <summary>
/// Simulates realistic network conditions between the API and the browser
/// (TCP, proxies, load balancers, CDNs). Treat this as infrastructure you do
/// not control - please do not modify it.
/// </summary>
internal static class NetworkConditions
{
    public static async Task WriteAsync(HttpResponse response, byte[] bytes)
    {
        if (bytes.Length > 4 && Random.Shared.NextDouble() < 0.35)
        {
            var cut = Random.Shared.Next(1, bytes.Length - 1);
            await response.Body.WriteAsync(bytes.AsMemory(0, cut));
            await response.Body.FlushAsync();
            await Task.Delay(15);
            await response.Body.WriteAsync(bytes.AsMemory(cut));
        }
        else
        {
            await response.Body.WriteAsync(bytes);
        }

        await response.Body.FlushAsync();
    }
}
