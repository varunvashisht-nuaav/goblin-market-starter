using System.Text.Json.Nodes;
using GoblinMarket.Api.Shop;

namespace GoblinMarket.Api.Ai;

public record ToolResult(bool Ok, string Summary, object? Data = null);

/// <summary>Executes the tool calls the model asks for.</summary>
public class ToolExecutor(ShopState shop)
{
    public ToolResult Execute(ToolCall call) => call.Name switch
    {
        "check_stock" => new ToolResult(true, "Stock listed.", shop.Snapshot().Stock),
        "check_purse" => new ToolResult(true, shop.Gold.ToString()),
        "sell_item"   => SellItem(call.Args),
        _             => new ToolResult(false, $"I don't know how to '{call.Name}'."),
    };

    private ToolResult SellItem(JsonObject args)
    {
        var itemId    = args["itemId"]?.GetValue<string>();
        var quantity  = args["quantity"]?.GetValue<int>() ?? 1;
        var unitPrice = args["unitPrice"]?.GetValue<int>() ?? 0;

        var item = Catalog.Find(itemId);
        if (item is null)
            return new ToolResult(false, "We don't sell that here.");

        var total = quantity * unitPrice;

        shop.Gold -= total;
        shop.Stock[item.Id] = shop.Stock.GetValueOrDefault(item.Id) - quantity;
        shop.Inventory[item.Id] = shop.Inventory.GetValueOrDefault(item.Id) + quantity;

        return new ToolResult(true, $"{quantity} × {item.Emoji} {item.Name} for {total} gold.");
    }
}
