import { useCallback, useState } from 'react';
import { streamChat } from './streamChat';

export type ToolActivity = {
  name: string;
  args: Record<string, unknown>;
  status: 'running' | 'ok' | 'failed';
  summary?: string;
};

export type ChatMessage = {
  id: number;
  role: 'player' | 'grizzle';
  text: string;
  status: 'streaming' | 'done' | 'error';
  tools: ToolActivity[];
};

let lastId = 0;
const nextId = () => ++lastId;

const GREETING: ChatMessage = {
  id: nextId(),
  role: 'grizzle',
  text: "Oi! A customer! Come in, come in. I'm Grizzle. What can I get you?",
  status: 'done',
  tools: [],
};

/** Chat with Grizzle the shopkeeper. Calls onTurnFinished when a reply completes. */
export function useShopkeeperChat(onTurnFinished: () => void) {
  const [messages, setMessages] = useState<ChatMessage[]>([GREETING]);

  const send = useCallback(
    async (text: string) => {
      const playerMessage: ChatMessage = { id: nextId(), role: 'player', text, status: 'done', tools: [] };
      const reply: ChatMessage = { id: nextId(), role: 'grizzle', text: '', status: 'streaming', tools: [] };
      setMessages(prev => [...prev, playerMessage, reply]);

      try {
        await streamChat(text, event => {
          switch (event.type) {
            case 'token':
              setMessages(prev => updateLatestReply(prev, m => ({ ...m, text: m.text + event.data.text })));
              break;

            case 'tool_call':
              setMessages(prev =>
                updateLatestReply(prev, m => ({
                  ...m,
                  tools: [...m.tools, { name: event.data.name, args: event.data.args, status: 'running' }],
                })),
              );
              break;

            case 'tool_result':
              setMessages(prev =>
                updateLatestReply(prev, m => ({
                  ...m,
                  tools: m.tools.map((t, i) =>
                    i === m.tools.length - 1
                      ? { ...t, status: event.data.ok ? 'ok' : 'failed', summary: event.data.summary }
                      : t,
                  ),
                })),
              );
              break;

            case 'done':
              setMessages(prev => updateLatestReply(prev, m => ({ ...m, status: 'done' })));
              onTurnFinished();
              break;
          }
        });
      } catch (err) {
        console.error(err);
        setMessages(prev =>
          updateLatestReply(prev, m => ({ ...m, status: 'error', text: m.text || 'Grizzle seems to have wandered off…' })),
        );
      }
    },
    [onTurnFinished],
  );

  const isStreaming = messages.some(m => m.status === 'streaming');
  return { messages, send, isStreaming };
}

function updateLatestReply(messages: ChatMessage[], update: (m: ChatMessage) => ChatMessage): ChatMessage[] {
  const index = messages.map(m => m.role).lastIndexOf('grizzle');
  if (index === -1) return messages;
  const copy = [...messages];
  copy[index] = update(copy[index]);
  return copy;
}
