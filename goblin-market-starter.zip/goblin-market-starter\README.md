# 🪙 Goblin Market — starter

Grizzle is a goblin shopkeeper run by an "AI" agent. You chat with him, he
streams his replies word by word, and he can use **tools** to check stock,
check your purse and sell you things.

The "LLM" is a local mock (`server/Ai/MockShopkeeperModel.cs`) so no API key
is needed. Treat it like a real third-party model: a black box you can't change.

## Requirements

- .NET 8 SDK — `dotnet --version`
- Node 18+ — `node --version`

## Run it (two terminals)

```bash
# terminal 1 — API on http://localhost:5080
cd server
dotnet run
```

```bash
# terminal 2 — UI on http://localhost:5175
cd client
npm install
npm run dev
```

Open http://localhost:5175.

## How it fits together

```
React (Vite)  ──POST /api/chat──▶  ASP.NET Core minimal API
   ▲                                   │
   │   Server-Sent Events stream:      ├─ MockShopkeeperModel  (the "LLM": plans replies + tool calls)
   │   token / tool_call /             ├─ ToolExecutor         (runs the tools the model asks for)
   └── tool_result / done ◀────────────┘  ShopState            (gold, stock, inventory — in memory)
```

## Files

### client/
- `src/App.tsx` — layout: chat, quick prompts, purse / bag / shelves sidebar.
- `src/useShopkeeperChat.ts` — chat state; sends a message and applies stream events.
- `src/streamChat.ts` — calls `POST /api/chat` and parses the SSE stream.
- `src/api.ts` — `GET /api/state`, `POST /api/reset`.

### server/
- `Program.cs` — endpoints and the agent loop (model → tool → model → stream).
- `Ai/MockShopkeeperModel.cs` — the mock LLM. **Don't change it.**
- `Ai/ToolExecutor.cs` — executes tool calls.
- `Shop/Catalog.cs`, `Shop/ShopState.cs` — price list and game state.
- `Streaming/SseWriter.cs` — writes SSE frames.

You may use any AI coding assistant you like.
