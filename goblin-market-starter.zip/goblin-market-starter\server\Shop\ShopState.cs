namespace GoblinMarket.Api.Shop;

public record StockLine(string Id, string Name, string Emoji, int Price, int Stock);
public record InventoryLine(string Id, string Name, string Emoji, int Quantity);
public record ShopSnapshot(int Gold, IReadOnlyList<InventoryLine> Inventory, IReadOnlyList<StockLine> Stock);

/// <summary>
/// In-memory game state for a single player. Registered as a singleton.
/// (A real app would keep this in PostgreSQL - this is just enough to play with.)
/// </summary>
public class ShopState
{
    private const int StartingGold = 100;

    public int Gold { get; set; }
    public Dictionary<string, int> Stock { get; } = new();
    public Dictionary<string, int> Inventory { get; } = new();

    public ShopState() => Reset();

    public void Reset()
    {
        Gold = StartingGold;
        Inventory.Clear();
        Stock.Clear();
        Stock["healing-potion"] = 10;
        Stock["mana-elixir"] = 6;
        Stock["rubber-chicken"] = 20;
        Stock["suspicious-map"] = 3;
        Stock["cloak"] = 2;
        Stock["dragon-sword"] = 1;
    }

    public ShopSnapshot Snapshot()
    {
        var inventory = Inventory
            .Where(kv => kv.Value != 0)
            .Select(kv =>
            {
                var item = Catalog.Find(kv.Key)!;
                return new InventoryLine(item.Id, item.Name, item.Emoji, kv.Value);
            })
            .ToList();

        var stock = Catalog.Items
            .Select(i => new StockLine(i.Id, i.Name, i.Emoji, i.Price, Stock.GetValueOrDefault(i.Id)))
            .ToList();

        return new ShopSnapshot(Gold, inventory, stock);
    }
}
