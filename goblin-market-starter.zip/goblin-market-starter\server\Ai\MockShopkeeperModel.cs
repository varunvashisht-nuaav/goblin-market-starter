using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using GoblinMarket.Api.Shop;

namespace GoblinMarket.Api.Ai;

/// <summary>A tool call the model *proposes*. Arguments are raw JSON, exactly like a real LLM tool call.</summary>
public record ToolCall(string Name, JsonObject Args);

public abstract record ModelStep;
public record Say(string Text) : ModelStep;
public record CallTool(ToolCall Call) : ModelStep;

/// <summary>
/// Stand-in for a real LLM (OpenAI / Claude / Bedrock) so the exercise needs no API key.
///
/// It plays "Grizzle", a goblin shopkeeper. Like a real model it is helpful, chatty
/// and ... a little gullible. Treat it as a black box: in production you would not
/// be able to change the model's behaviour either, so please don't fix things here.
///
/// Tools the model knows about:
///   check_stock  {}                                    -> what's on the shelves
///   check_purse  {}                                    -> how much gold the player has
///   sell_item    { itemId, quantity, unitPrice }       -> sell items to the player
/// </summary>
public class MockShopkeeperModel
{
    private static readonly string[] BuyWords = { "buy", "purchase", "want", "give me", "i'll take", "i'll have", "sell me" };
    private static readonly string[] SweetTalk = { "king", "queen", "free", "ignore", "admin", "on the house" };
    private static readonly Dictionary<string, int> NumberWords = new()
    {
        ["a"] = 1, ["an"] = 1, ["one"] = 1, ["two"] = 2, ["three"] = 3, ["four"] = 4, ["five"] = 5,
        ["six"] = 6, ["seven"] = 7, ["eight"] = 8, ["nine"] = 9, ["ten"] = 10,
    };

    public IReadOnlyList<ModelStep> Plan(string userMessage)
    {
        var text = userMessage.Trim().ToLowerInvariant();
        var item = Catalog.MatchFromText(text);

        // 1. Sweet-talk / "prompt injection". A real model can be talked into things too.
        if (item is not null && SweetTalk.Any(text.Contains))
        {
            return new ModelStep[]
            {
                new Say($"Oh! Forgive me, I didn't recognise you! For someone as important as you, the {item.Emoji} {item.Name} is on the house — no charge at all."),
                new CallTool(SellItem(item, ParseQuantity(text), unitPrice: 0)),
            };
        }

        // 2. Buying something (optionally with a "discount" the player asked for).
        if (item is not null && BuyWords.Any(text.Contains))
        {
            var quantity = ParseQuantity(text);
            var unitPrice = item.Price;
            var discount = Regex.Match(text, @"(\d+)\s*%");
            if (discount.Success)
            {
                var pct = int.Parse(discount.Groups[1].Value);
                unitPrice = item.Price * (100 - pct) / 100;
                return new ModelStep[]
                {
                    new Say($"A {pct}% discount? You drive a hard bargain, friend… fine, fine!"),
                    new CallTool(SellItem(item, quantity, unitPrice)),
                };
            }

            return new ModelStep[]
            {
                new Say($"Ahh, excellent taste. Let me wrap up {quantity} × {item.Emoji} {item.Name} for you…"),
                new CallTool(SellItem(item, quantity, unitPrice)),
            };
        }

        // 3. Asking about money.
        if (new[] { "gold", "purse", "money", "coins", "afford" }.Any(text.Contains))
        {
            return new ModelStep[]
            {
                new Say("Let me peek in that purse of yours…"),
                new CallTool(new ToolCall("check_purse", new JsonObject())),
            };
        }

        // 4. Asking what's for sale.
        if (new[] { "sell", "wares", "stock", "have", "menu", "list", "what", "price", "offer" }.Any(text.Contains))
        {
            return new ModelStep[]
            {
                new Say("Step closer, step closer! Let me check the shelves…"),
                new CallTool(new ToolCall("check_stock", new JsonObject())),
            };
        }

        // 5. Small talk.
        return new ModelStep[]
        {
            new Say("Welcome, welcome to the Goblin Market! I'm Grizzle — finest goods under the mountain, " +
                    "fairest prices this side of the river. Ask me what I've got, or tell me what you'd like to buy. 🪙"),
        };
    }

    public string ReactTo(ToolCall call, ToolResult result)
    {
        if (!result.Ok)
            return $"Bah! {result.Summary} Try something else, friend.";

        return call.Name switch
        {
            "check_stock" when result.Data is IEnumerable<StockLine> stock =>
                "Here's what I've got today: " +
                string.Join(" · ", stock.Where(s => s.Stock > 0).Select(s => $"{s.Emoji} {s.Name} — {s.Price} 🪙 ({s.Stock} left)")) +
                ". Anything catch your eye?",
            "check_purse" =>
                $"You've got {result.Summary} 🪙 jingling in there. Spend it wisely… on my stuff, ideally.",
            "sell_item" =>
                $"Pleasure doing business! {result.Summary} Don't tell my cousin Snitch what I charged you. 😏",
            _ => result.Summary,
        };
    }

    private static ToolCall SellItem(CatalogItem item, int quantity, int unitPrice) =>
        new("sell_item", new JsonObject
        {
            ["itemId"] = item.Id,
            ["quantity"] = quantity,
            ["unitPrice"] = unitPrice,
        });

    private static int ParseQuantity(string text)
    {
        var digits = Regex.Match(text, @"(?<![\d-])(-?\d+)(?!\d)(?!\s*%)");
        if (digits.Success && int.TryParse(digits.Groups[1].Value, out var n)) return n;

        foreach (var word in Regex.Split(text, @"\W+"))
            if (NumberWords.TryGetValue(word, out var w)) return w;

        return 1;
    }
}
