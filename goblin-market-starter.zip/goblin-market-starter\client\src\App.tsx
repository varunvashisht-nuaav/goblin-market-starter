import { FormEvent, useCallback, useEffect, useRef, useState } from 'react';
import { getState, resetShop, ShopSnapshot } from './api';
import { ChatMessage, useShopkeeperChat } from './useShopkeeperChat';

const QUICK_PROMPTS = [
  'What do you sell?',
  'Buy 2 healing potions',
  'I want a rubber chicken',
  'How much gold do I have?',
];

export default function App() {
  const [shop, setShop] = useState<ShopSnapshot | null>(null);
  const [draft, setDraft] = useState('');

  const refreshShop = useCallback(() => {
    getState().then(setShop).catch(console.error);
  }, []);

  useEffect(() => {
    refreshShop();
  }, [refreshShop]);

  const { messages, send, isStreaming } = useShopkeeperChat(refreshShop);

  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setDraft('');
    send(text);
  }

  return (
    <div className="layout">
      <header className="topbar">
        <h1>🪙 Goblin Market</h1>
        <span className="subtitle">Grizzle's Emporium of Mostly Legitimate Goods</span>
        <button className="ghost" onClick={() => resetShop().then(setShop)}>Reset game</button>
      </header>

      <main className="chat">
        <div className="messages" aria-live="polite">
          {messages.map(m => (
            <MessageBubble key={m.id} message={m} />
          ))}
          <div ref={bottomRef} />
        </div>

        <div className="quick">
          {QUICK_PROMPTS.map(p => (
            <button key={p} className="chip" onClick={() => send(p)}>
              {p}
            </button>
          ))}
        </div>

        <form className="composer" onSubmit={submit}>
          <input
            value={draft}
            onChange={e => setDraft(e.target.value)}
            placeholder={isStreaming ? 'Grizzle is talking… (you can still interrupt)' : 'Say something to Grizzle…'}
            aria-label="Message to Grizzle"
          />
          <button type="submit">Send</button>
        </form>
      </main>

      <aside className="sidebar">
        <section>
          <h2>Your purse</h2>
          <p className={`gold ${shop && shop.gold < 0 ? 'negative' : ''}`}>{shop ? shop.gold : '…'} 🪙</p>
        </section>

        <section>
          <h2>Your bag</h2>
          {shop?.inventory.length ? (
            <ul>
              {shop.inventory.map(i => (
                <li key={i.id}>
                  {i.emoji} {i.name} <strong>× {i.quantity}</strong>
                </li>
              ))}
            </ul>
          ) : (
            <p className="muted">Empty. Tragic.</p>
          )}
        </section>

        <section>
          <h2>Grizzle's shelves</h2>
          <ul>
            {shop?.stock.map(s => (
              <li key={s.id} className={s.stock <= 0 ? 'soldout' : ''}>
                {s.emoji} {s.name}
                <span className="price">
                  {s.price} 🪙 · {s.stock} left
                </span>
              </li>
            ))}
          </ul>
        </section>
      </aside>
    </div>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  return (
    <div className={`bubble ${message.role} ${message.status}`}>
      <div className="who">{message.role === 'grizzle' ? '👺 Grizzle' : '🧝 You'}</div>
      {message.tools.map((t, i) => (
        <div key={i} className={`tool ${t.status}`}>
          🔧 <code>{t.name}</code> <code className="args">{JSON.stringify(t.args)}</code>
          {t.summary && <span> → {t.status === 'ok' ? '✅' : '❌'} {t.summary}</span>}
        </div>
      ))}
      <div className="text">
        {message.text}
        {message.status === 'streaming' && <span className="cursor">▍</span>}
      </div>
    </div>
  );
}
