import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5175,
    proxy: {
      // ASP.NET Core API (see ../server)
      '/api': 'http://localhost:5080',
    },
  },
});
