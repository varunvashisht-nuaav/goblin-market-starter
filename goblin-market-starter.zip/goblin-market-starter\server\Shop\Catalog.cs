namespace GoblinMarket.Api.Shop;

public record CatalogItem(string Id, string Name, string Emoji, int Price, string[] Keywords);

/// <summary>The official price list. Prices are in gold coins.</summary>
public static class Catalog
{
    public static readonly IReadOnlyList<CatalogItem> Items = new List<CatalogItem>
    {
        new("healing-potion", "Healing Potion",               "🧪", 12,  new[] { "potion", "healing", "heal" }),
        new("mana-elixir",    "Mana Elixir",                  "🔮", 18,  new[] { "elixir", "mana" }),
        new("rubber-chicken", "Rubber Chicken (+1 Morale)",   "🐔", 3,   new[] { "chicken", "rubber" }),
        new("suspicious-map", "Suspicious Map",               "🗺️", 25,  new[] { "map" }),
        new("cloak",          "Cloak of Mild Invisibility",   "🧥", 60,  new[] { "cloak", "invisibility" }),
        new("dragon-sword",   "Dragon Sword",                 "🗡️", 500, new[] { "sword", "dragon" }),
    };

    public static CatalogItem? Find(string? id) =>
        Items.FirstOrDefault(i => string.Equals(i.Id, id, StringComparison.OrdinalIgnoreCase));

    public static CatalogItem? MatchFromText(string text) =>
        Items.FirstOrDefault(i => i.Keywords.Any(k => text.Contains(k, StringComparison.OrdinalIgnoreCase)));
}
