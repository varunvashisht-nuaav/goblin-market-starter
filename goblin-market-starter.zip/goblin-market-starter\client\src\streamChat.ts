// Talks to POST /api/chat, which replies with a Server-Sent Events stream:
//
//   event: token
//   data: {"text":"Hello "}
//
//   event: tool_call
//   data: {"name":"sell_item","args":{...}}
//
// We use fetch() + a stream reader instead of EventSource because EventSource
// can only do GET requests.

export type ChatEvent =
  | { type: 'token'; data: { text: string } }
  | { type: 'tool_call'; data: { name: string; args: Record<string, unknown> } }
  | { type: 'tool_result'; data: { name: string; ok: boolean; summary: string } }
  | { type: 'done'; data: Record<string, never> };

export async function streamChat(
  message: string,
  onEvent: (event: ChatEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message }),
    signal,
  });
  if (!res.ok || !res.body) throw new Error(`Chat failed: ${res.status}`);

  const reader = res.body.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    const chunk = decoder.decode(value);
    for (const frame of chunk.split('\n\n')) {
      if (!frame.trim()) continue;
      const event = parseFrame(frame);
      if (event) onEvent(event);
    }
  }
}

function parseFrame(frame: string): ChatEvent | null {
  let type = 'message';
  let data = '';
  for (const line of frame.split('\n')) {
    if (line.startsWith('event:')) type = line.slice(6).trim();
    else if (line.startsWith('data:')) data += line.slice(5).trim();
  }
  try {
    return { type, data: JSON.parse(data) } as ChatEvent;
  } catch {
    return null; // ignore keep-alives / malformed frames
  }
}
