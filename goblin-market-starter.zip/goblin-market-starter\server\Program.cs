using System.Text.RegularExpressions;
using GoblinMarket.Api.Ai;
using GoblinMarket.Api.Shop;
using GoblinMarket.Api.Streaming;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.UseUrls("http://localhost:5080");

builder.Services.AddSingleton<ShopState>();
builder.Services.AddSingleton<MockShopkeeperModel>();
builder.Services.AddSingleton<ToolExecutor>();

var app = builder.Build();

app.MapGet("/api/state", (ShopState shop) => shop.Snapshot());

app.MapPost("/api/reset", (ShopState shop) =>
{
    shop.Reset();
    return shop.Snapshot();
});

// Streams the shopkeeper's reply as Server-Sent Events:
//   token        { text }                    - a piece of the reply
//   tool_call    { name, args }              - the model asked to use a tool
//   tool_result  { name, ok, summary }       - what happened when we ran it
//   done         {}                          - the reply is finished
app.MapPost("/api/chat", async (ChatRequest request, HttpContext http, MockShopkeeperModel model, ToolExecutor tools) =>
{
    http.Response.ContentType = "text/event-stream";
    http.Response.Headers.CacheControl = "no-cache";
    var sse = new SseWriter(http.Response);

    foreach (var step in model.Plan(request.Message))
    {
        switch (step)
        {
            case Say say:
                await StreamTextAsync(sse, say.Text);
                break;

            case CallTool { Call: var call }:
                await sse.SendAsync("tool_call", new { name = call.Name, args = call.Args });
                var result = tools.Execute(call);
                await sse.SendAsync("tool_result", new { name = call.Name, ok = result.Ok, summary = result.Summary });
                await StreamTextAsync(sse, " " + model.ReactTo(call, result));
                break;
        }
    }

    await sse.SendAsync("done", new { });
});

app.Run();

// "Typing" the reply word by word, like an LLM streaming tokens.
static async Task StreamTextAsync(SseWriter sse, string text)
{
    foreach (var token in Regex.Split(text, @"(?<=\s)"))
    {
        if (token.Length == 0) continue;
        await sse.SendAsync("token", new { text = token });
        await Task.Delay(Random.Shared.Next(40, 110));
    }
}

public record ChatRequest(string Message);
