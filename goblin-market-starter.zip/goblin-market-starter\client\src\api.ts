export type StockLine = { id: string; name: string; emoji: string; price: number; stock: number };
export type InventoryLine = { id: string; name: string; emoji: string; quantity: number };
export type ShopSnapshot = { gold: number; inventory: InventoryLine[]; stock: StockLine[] };

export async function getState(): Promise<ShopSnapshot> {
  const res = await fetch('/api/state');
  if (!res.ok) throw new Error(`GET /api/state failed: ${res.status}`);
  return res.json();
}

export async function resetShop(): Promise<ShopSnapshot> {
  const res = await fetch('/api/reset', { method: 'POST' });
  if (!res.ok) throw new Error(`POST /api/reset failed: ${res.status}`);
  return res.json();
}
